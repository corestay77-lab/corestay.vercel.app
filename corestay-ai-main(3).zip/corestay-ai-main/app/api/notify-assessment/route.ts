import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

type LeadPayload = {
  nama?: string;
  hotel?: string;
  kota?: string;
  kamar?: string;
  whatsapp?: string;
  email?: string;
};

type ExistingScores = {
  overall?: number;
  revenue?: number;
  operasional?: number;
  sdm?: number;
  manajemen?: number;
};

type PreOpeningScores = {
  overall?: number;
  status?: string;
  risk?: string;
};

type NotifyPayload = {
  type?: "existing" | "preopening";
  lead?: LeadPayload;
  scores?: ExistingScores | PreOpeningScores;
  diagnosis?: string;
  recommendation?: string;
  priority?: string;
  priorityActions?: string[];
};

function escapeHtml(value: unknown) {
  const text = value === null || value === undefined ? "-" : String(value);

  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function buildEmailHtml(payload: NotifyPayload) {
  const lead = payload.lead || {};
  const scores = payload.scores || {};
  const isPreOpening = payload.type === "preopening";

  const title = isPreOpening
    ? "Lead Baru — Pre-opening Readiness Assessment"
    : "Lead Baru — Hotel Health Assessment";

  const overall =
    "overall" in scores && typeof scores.overall === "number"
      ? scores.overall
      : "-";

  const scoreRows = isPreOpening
    ? [
        ["Overall Readiness", overall],
        ["Status Kesiapan", (scores as PreOpeningScores).status ?? "-"],
        ["Level Risiko", (scores as PreOpeningScores).risk ?? "-"],
      ]
    : [
        ["Overall Score", overall],
        ["Revenue & Pricing", (scores as ExistingScores).revenue ?? "-"],
        ["Operasional", (scores as ExistingScores).operasional ?? "-"],
        ["SDM", (scores as ExistingScores).sdm ?? "-"],
        ["Manajemen", (scores as ExistingScores).manajemen ?? "-"],
      ];

  const scoreRowsHtml = scoreRows
    .map(
      ([label, value]) =>
        `<tr><td style="padding:6px 12px;color:#64748b;">${escapeHtml(
          label
        )}</td><td style="padding:6px 12px;font-weight:600;color:#0f172a;">${escapeHtml(
          value
        )}</td></tr>`
    )
    .join("");

  const priorityActionsHtml =
    payload.priorityActions && payload.priorityActions.length > 0
      ? `<div style="margin-top:16px;">
           <p style="margin:0 0 6px;font-weight:600;color:#0f172a;">Priority Actions</p>
           <ul style="margin:0;padding-left:18px;color:#334155;">
             ${payload.priorityActions
               .map((item) => `<li style="margin-bottom:4px;">${escapeHtml(item)}</li>`)
               .join("")}
           </ul>
         </div>`
      : "";

  return `
  <div style="font-family:Arial,Helvetica,sans-serif;max-width:600px;margin:0 auto;color:#0f172a;">
    <p style="text-transform:uppercase;letter-spacing:2px;font-size:12px;color:#2563eb;font-weight:700;">
      Core Stay_Advisory
    </p>
    <h2 style="margin:8px 0 16px;">${escapeHtml(title)}</h2>

    <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
      <tr><td style="padding:6px 12px;color:#64748b;">Nama</td><td style="padding:6px 12px;font-weight:600;">${escapeHtml(lead.nama)}</td></tr>
      <tr><td style="padding:6px 12px;color:#64748b;">Hotel</td><td style="padding:6px 12px;font-weight:600;">${escapeHtml(lead.hotel)}</td></tr>
      <tr><td style="padding:6px 12px;color:#64748b;">Kota</td><td style="padding:6px 12px;font-weight:600;">${escapeHtml(lead.kota)}</td></tr>
      <tr><td style="padding:6px 12px;color:#64748b;">Jumlah Kamar</td><td style="padding:6px 12px;font-weight:600;">${escapeHtml(lead.kamar)}</td></tr>
      <tr><td style="padding:6px 12px;color:#64748b;">WhatsApp</td><td style="padding:6px 12px;font-weight:600;">${escapeHtml(lead.whatsapp)}</td></tr>
      <tr><td style="padding:6px 12px;color:#64748b;">Email</td><td style="padding:6px 12px;font-weight:600;">${escapeHtml(lead.email || "-")}</td></tr>
    </table>

    <p style="font-weight:700;margin:0 0 6px;">Hasil Assessment</p>
    <table style="width:100%;border-collapse:collapse;background:#f8fafc;border-radius:8px;overflow:hidden;">
      ${scoreRowsHtml}
    </table>

    ${
      payload.priority
        ? `<p style="margin-top:16px;"><strong>Prioritas:</strong> ${escapeHtml(payload.priority)}</p>`
        : ""
    }

    ${
      payload.diagnosis
        ? `<p style="margin-top:8px;"><strong>Diagnosis:</strong> ${escapeHtml(payload.diagnosis)}</p>`
        : ""
    }

    ${
      payload.recommendation
        ? `<p style="margin-top:8px;"><strong>Rekomendasi:</strong> ${escapeHtml(payload.recommendation)}</p>`
        : ""
    }

    ${priorityActionsHtml}

    <p style="margin-top:24px;font-size:12px;color:#94a3b8;">
      Email ini dikirim otomatis begitu lead menyelesaikan assessment di website Core Stay_Advisory.
    </p>
  </div>`;
}

export async function POST(request: NextRequest) {
  const apiKey = process.env.RESEND_API_KEY;
  const notifyEmail = process.env.ASSESSMENT_NOTIFY_EMAIL;
  const fromEmail =
    process.env.ASSESSMENT_FROM_EMAIL || "Core Stay_Advisory <onboarding@resend.dev>";

  if (!apiKey || !notifyEmail) {
    console.error(
      "notify-assessment: RESEND_API_KEY atau ASSESSMENT_NOTIFY_EMAIL belum diset."
    );

    return NextResponse.json(
      { ok: false, error: "Email service belum dikonfigurasi." },
      { status: 500 }
    );
  }

  let payload: NotifyPayload;

  try {
    payload = await request.json();
  } catch {
    return NextResponse.json(
      { ok: false, error: "Payload tidak valid." },
      { status: 400 }
    );
  }

  const lead = payload.lead || {};
  const hotelName = lead.hotel || "Hotel (tanpa nama)";
  const subjectPrefix =
    payload.type === "preopening" ? "[Pre-opening]" : "[Assessment]";

  const html = buildEmailHtml(payload);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: fromEmail,
        to: notifyEmail.split(",").map((item) => item.trim()),
        subject: `${subjectPrefix} Lead baru: ${hotelName}`,
        html,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!response.ok) {
      const errorText = await response.text();
      console.error("notify-assessment: Resend error", errorText);

      return NextResponse.json(
        { ok: false, error: "Gagal mengirim email." },
        { status: 502 }
      );
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    clearTimeout(timeout);
    console.error("notify-assessment: fetch error", error);

    return NextResponse.json(
      { ok: false, error: "Gagal mengirim email." },
      { status: 500 }
    );
  }
}
