﻿import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://vkejwklhijophavlosze.supabase.co";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "placeholder-anon-key-build-time";

if (!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY && typeof window !== "undefined") {
  console.error(
    "NEXT_PUBLIC_SUPABASE_ANON_KEY tidak ditemukan. Cek Environment Variables di Vercel."
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
